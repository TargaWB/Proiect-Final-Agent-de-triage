# Agent de Triaj ITSM

Agent care primește un tichet IT în text liber (română sau engleză), îl clasifică pe
prioritate (P1–P4), categorie și echipă pe baza tichetelor istorice similare, apoi decide:
rutare automată sau aprobare umană. Fiecare decizie are motivare, surse citate și un trace
complet în Arize Phoenix.

**LLM-ul doar propune.** Propunerea e un JSON validat cu Pydantic; decizia o ia un
guardrail determinist, iar execuția trece numai prin tool-uri cu validări.

## Pornire rapidă (Docker)

```bash
cp .env.example .env          # pune GROQ_API_KEY (gratuit: console.groq.com)
docker compose up --build
```

| Serviciu | Adresă |
|---|---|
| Interfața: Clasificare, KPI & cost, Jira & integrări (Streamlit) | http://localhost:8501 |
| **Aprobări**, aplicație separată pentru responsabili | http://localhost:8502 |
| API (FastAPI, documentație interactivă) | http://localhost:8000/docs |
| Arize Phoenix | http://localhost:6006 |

Prima construire durează câteva minute: imaginea include modelul de embedding (~240 MB),
ca pornirea să nu mai descarce nimic. Datele (400 de tichete istorice) sunt deja în repo;
indexul se construiește singur la prima pornire.

## Parcurs de utilizare, în 5 minute

1. **Clasificare**: scrie-ți numele în bara din stânga, apoi un tichet, de ex.
   *„Serverele din AWS sunt căzute, aplicația de plăți nu merge pentru niciun client”*. Primești
   prioritatea, echipa, motivarea, citările și exemplele din istoric (cu rezolvarea lor).
2. Trimite un tichet de risc scăzut (*„Outlook nu mai sincronizează, nu e urgent”*): e rutat
   automat. Trimite-l din nou identic: e recunoscut ca duplicat, fără apel LLM.
3. **Aprobări** (http://localhost:8502, aplicație separată: responsabilii văd doar asta): tichetul P1 te așteaptă aici. Aprobă-l, eventual cu o corecție de echipă.
4. **Phoenix** → `triaj-agent` → **Sessions** → `INC-000X`: tot drumul tichetului, cu
   retrieverul și documentele aduse, apelul LLM cu tokenii, guardrail-ul (propunere → decizie),
   tool-ul executat și aprobarea omului (cine, ce a corectat).
5. **KPI & FinOps**: auto-rezolvare, intervenție umană, timp până la rutare, tokeni și
   cost per tichet, plus rezultatele evaluării.

## Jira, automat în ambele direcții

```
Issue nou în Jira ──(webhook sau sincronizare periodică)──> agent ──> reguli de siguranță
        ^                                                                 │
        └──── comentariu cu decizia + prioritate + etichete ──────────────┘   (și după decizia omului)
```

- **Intrare**: `POST /webhooks/jira` (evenimentul *Issue created*) sau polling JQL la fiecare
  `JIRA_POLL_SECONDS` secunde, variantă simplă pe laptop, pentru că Jira Cloud nu poate
  apela `localhost` fără un tunel (ngrok).
- **Idempotent**: o cheie Jira se clasifică o singură dată, oricâte webhook-uri sau sincronizări vin.
- **Ieșire**: comentariu cu decizia și motivarea, prioritatea Jira (P1→Highest … P4→Low) și etichete
  `triaj-ai`, `triaj-auto` / `triaj-review`, `echipa-…`. După aprobarea sau respingerea omului, încă un
  comentariu, cu corecțiile făcute. Fiecare acțiune apare în jurnal (reușită sau eroare) și se poate retrimite.
- **Securitate**: `JIRA_WEBHOOK_SECRET` (semnătura HMAC `X-Hub-Signature` din Jira Cloud sau `?token=`).
- **Fără credențiale** = mod simulare: fluxul e identic, iar ce s-ar fi scris în Jira apare doar în jurnal.
  Configurarea e în `.env.example` și în pagina **Jira & integrări**.

Endpoint-uri: `GET /integrations/jira/status`, `POST /integrations/jira/test`, `POST /integrations/jira/sync`,
`GET /integrations/jira/events`, `GET /integrations/jira/tickets`, `POST /integrations/jira/push/{id}`.

## Cerințe → unde sunt

| # | Cerință | Implementare |
|---|---|---|
| 1 | Arhitectură documentată: roluri, tool-uri, handoff-uri, stare, diagrame | [docs/architecture.md](docs/architecture.md) |
| 2 | Separare reasoning / execuție, JSON validat cu Pydantic | `agent/classifier.py` → `agent/schemas.py` → `agent/router.py` → `agent/tools.py` |
| 3 | Model open source, zero cost | Groq `openai/gpt-oss-20b` (free tier); Ollama local pentru few-shot mic și LoRA |
| 4 | RAG cu ChromaDB, citări, evaluare RAGAS | `agent/retrieval.py`, `scripts/ragas_eval.py` |
| 5 | Human-in-the-loop cu praguri justificate | `agent/router.py`, pagina Aprobări, [praguri](docs/architecture.md#guardrail-praguri-și-de-ce) |
| 6 | Audit și observabilitate cu Arize Phoenix | `agent/telemetry.py`, tabela `audit_log`, sesiune Phoenix pe fiecare tichet |
| 7 | Date mock realiste, 200–500 | 500 de tichete din Kaggle (400 istoric + 100 test), `scripts/import_kaggle.py` |
| 8 | KPI măsurați, manual vs agentic | pagina KPI, `scripts/evaluate.py`, [docs/evaluation.md](docs/evaluation.md) |
| 9 | FastAPI în Docker + Streamlit, flux complet end-to-end | `api/`, `ui/`, `docker-compose.yml` |
| — | Few-shot vs fine-tuned LoRA | `finetune/lora_finetune.ipynb` + `scripts/evaluate.py` |
| — | Framework compatibil OpenTelemetry/OpenInference, FinOps | LangChain + LangGraph, [docs/finops.md](docs/finops.md) |

## Evaluare

```bash
docker compose exec api python scripts/evaluate.py          # few-shot pe Groq + simulare manual vs agentic
docker compose exec api python scripts/ragas_eval.py --n 20 # RAG: retrieval + RAGAS
```

Rezultatele apar în `eval/results/` (inclusiv `REPORT.md`) și în pagina KPI.
Rezultate pe 100 tichete de test (detalii și limite în [docs/evaluation.md](docs/evaluation.md)):

| Model | Prioritate macro-F1 | Latență p50 | Tokeni/tichet | Cost/1000 |
|---|---|---|---|---|
| few-shot gpt-oss-20b | 0.58 | 7541 ms | 996 | $0.1039 |
| few-shot llama3.2 3B | 0.521 | 2601 ms | 955 | $0 |
| LoRA llama3.2 3B (400 tichete) | 0.857 | 1112 ms | 221 | $0 |

KPI simulat manual → agentic: timp până la rutare 1.03 h → 0.038 h, rutări greșite 20% → 2.2%,
decizii umane 100% → 19%, MTTR −3,6% (presupuneri în `agent/config.py`). RAGAS (n=20):
faithfulness 0.62. Limite: set de test mic (14 P1), 5 P1 ratate fără om la few-shot gpt-oss,
LoRA nu dă confidence/citări.

Few-shot vs LoRA, pas cu pas: [docs/evaluation.md](docs/evaluation.md#1-few-shot-vs-fine-tuned-cu-lora).

## Rulare fără Docker

```bash
python3 -m venv venv && source venv/bin/activate
pip install -r requirements-eval.txt
export GROQ_API_KEY=...
docker run -d -p 6006:6006 arizephoenix/phoenix:version-20.16.0     # opțional, pentru trace-uri
uvicorn api.main:app --port 8000        # terminal 1
streamlit run ui/app.py                  # terminal 2
pytest                                   # 36 de teste, fără rețea și fără cheie (LLM simulat)
```

## Structură

```
agent/                 nucleul agentului
  graph.py             graful LangGraph: noduri, stare, tranziții
  classifier.py        reasoning: prompt few-shot, apel LLM, validare, reîncercare
  router.py            guardrail: reguli de risc (fără LLM)
  tools.py             execuție: tool-uri deterministe cu validări
  jira.py              Jira: webhook, polling JQL, scriere înapoi, jurnal
  retrieval.py         ChromaDB + retrievere LangChain
  embeddings.py        embedding local multilingv
  schemas.py           contractele Pydantic
  service.py           trimitere, aprobare umană, KPI, FinOps
  telemetry.py         Phoenix / OpenInference
  db.py                SQLite: tichete, execuții, consum LLM, audit
  config.py            praguri, modele, prețuri, presupuneri de simulare
  lora_format.py       formatul de antrenare LoRA
api/main.py            FastAPI
ui/                    Streamlit: app.py (Clasificare, KPI & FinOps) și approver_app.py (doar Aprobări)
scripts/               import Kaggle, evaluare, RAGAS, set LoRA
finetune/               notebook Colab, Modelfile Ollama, train/test.jsonl
data/                  tickets.csv (400), test_tickets.csv (100)
eval/results/          rezultatele evaluărilor
docs/                  arhitectură, evaluare, FinOps
tests/                 teste unitare, flux complet, API, trace-uri
```

## Configurare

Totul e în `.env` și `agent/config.py`:

| Variabilă | Implicit | |
|---|---|---|
| `GROQ_API_KEY` | — | obligatoriu pentru Groq |
| `LLM_PROVIDER` | `groq` | sau `ollama` |
| `GROQ_MODEL` | `openai/gpt-oss-20b` | |
| `OLLAMA_MODEL` | `llama3.2` | |
| `TRACING_ENABLED` | `true` | |
| `APPROVER_CODE` | gol | cod de acces pentru aplicația de aprobări (opțional) |
| `CONFIDENCE_THRESHOLD` (config.py) | `0.70` | pragul de aprobare umană |
